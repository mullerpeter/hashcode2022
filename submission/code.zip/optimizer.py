from dataparser import Data
from tqdm import tqdm
import random


def run_optimisation(data: Data, num_steps=10):
    pbar = tqdm(range(num_steps))
    for i in pbar:
        continue
        # TODO: Implement Random Swaps
