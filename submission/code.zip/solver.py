from dataparser import Data, Role
import random
import numpy as np


def solve(data: Data):
    # TODO: Implement Greedy Solver
    return


def get_compatible_contributor(data: Data, role: Role, current_people, current_skills):
    if current_skills[role.skill_index]
    random.shuffle(data.contributors)
    for con in data.contributors:
        if con.skills[role.skill_index] >= role.level and con.name not in current_people:
            return con

    return None

def solve_peter(data: Data):
    project_scores = [project.get_score() for project in data.projects]
    sorted_scores_index = np.argsort(project_scores)[::-1]
    solution = []
    for project_index in sorted_scores_index:
        all_good = True
        current_people = []
        current_skills = np.zeros(len(data.all_skills))
        for role in data.projects[project_index].roles:
            role.assigned = get_compatible_contributor(data, role, current_people, current_skills)
            if role.assigned is None:
                all_good = False
            else:
                current_skills = np.maximum(current_skills, role.assigned.skills)
                current_people.append(role.assigned.name)
        if all_good:
            solution.append(data.projects[project_index])

    return solution


