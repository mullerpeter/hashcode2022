from dataparser import Data
from optimizer import run_optimisation
from score import score
from solver import solve, solve_peter
from zip_code import zip_code

if __name__ == '__main__':

    task_name = 'c_collaboration'
    print(task_name)
    data = Data(task_name)
    data.solution = solve_peter(data)
    data.write_solution()

    zip_code()



