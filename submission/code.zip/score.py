from dataparser import Data


def score(data: Data):
    task_score = 0
    # TODO: Implement Scoring
    return task_score
