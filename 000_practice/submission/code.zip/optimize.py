import random

def read_data_input(filename):
    file1 = open(filename, 'r')
    likes = []
    hates = []
    c = int(file1.readline())
    for _ in range(c):
        line = file1.readline().split()
        likes.append(line[1:])
        line = file1.readline().split()
        hates.append(line[1:])

    return likes, hates


def read_data_out(filename):
    file1 = open(filename, 'r')
    return file1.readline().split()[1:]


import networkx as nx
from tqdm import tqdm
import numpy as np


def solve_for(task_name):
    on_Pizza = read_data_out(f'output_data/{task_name}.out.txt')
    likes, hates = read_data_input(f'input_data/{task_name}.in.txt')
    all_ingredients = []
    for like in likes:
        all_ingredients += like

    for hate in hates:
        all_ingredients += hate

    all_ingredients = list(set(all_ingredients))
    new_on_pizza = np.zeros(len(all_ingredients))
    for ing in on_Pizza:
        new_on_pizza[all_ingredients.index(ing)] = 1
    on_Pizza = new_on_pizza
    new_likes = []
    for like in likes:
        new_like = []
        for ing in like:
            new_like.append(all_ingredients.index(ing))
        new_likes.append(new_like)
    likes = new_likes
    new_hates = []
    for hate in hates:
        new_hate = []
        for ing in hate:
            new_hate.append(all_ingredients.index(ing))
        new_hates.append(new_hate)
    hates = new_hates

    def score_option(ingredients):
        score = 0
        for i in range(len(likes)):
            if np.sum(ingredients[likes[i]]) == len(likes[i]) and np.sum(ingredients[hates[i]]) == 0:
                score += 1
        return score

    def do_random_swap(ingredients):
        to_test = random.choice(all_ingredients)
        test_ingredients = np.array(ingredients)
        if test_ingredients[all_ingredients.index(to_test)] == 1:
            test_ingredients[all_ingredients.index(to_test)] = 0
        else:
            test_ingredients[all_ingredients.index(to_test)] = 1
        if np.array_equal(test_ingredients, ingredients):
            return ingredients
        if score_option(test_ingredients) > score_option(ingredients):
            print(f'Better Score: {score_option(test_ingredients)}')
            textfile = open(f'output_data/{task_name}.out.txt', "w")
            textfile.write(str(int(np.sum(test_ingredients))))
            for i in range(len(test_ingredients)):
                if test_ingredients[i] != 0:
                    textfile.write(" " + all_ingredients[i])
            textfile.close()
        if score_option(test_ingredients) >= score_option(ingredients):
            return test_ingredients

        return ingredients

    def do_random_swap_customer(ingredients):
        test_index = random.choice([i for i in range(len(likes))])
        remove_add = random.choice([0, 1])
        test_ingredients = np.array(ingredients)
        for ing in likes[test_index]:
            test_ingredients[ing] = 1 - remove_add
        for ing in hates[test_index]:
            test_ingredients[ing] = 0 + remove_add

        if np.array_equal(test_ingredients, ingredients):
            return ingredients
        if score_option(test_ingredients) > score_option(ingredients):
            print(f'Better Score: {score_option(test_ingredients)}')
            textfile = open(f'output_data/{task_name}.out.txt', "w")
            textfile.write(str(int(np.sum(test_ingredients))))
            for i in range(len(test_ingredients)):
                if test_ingredients[i] != 0:
                    textfile.write(" " + all_ingredients[i])
            textfile.close()
        if score_option(test_ingredients) >= score_option(ingredients):
            return test_ingredients

        return ingredients

    for _ in tqdm(range(10000)):
        on_Pizza = do_random_swap(on_Pizza)
        on_Pizza = do_random_swap_customer(on_Pizza)

if __name__ == '__main__':
    solve_for('e_elaborate')
    # solve_for('d_difficult')
