import random


def read_data(filename):
    file1 = open(filename, 'r')
    likes = []
    hates = []
    c = int(file1.readline())
    for _ in range(c):
        line = file1.readline().split()
        likes.append(line[1:])
        line = file1.readline().split()
        hates.append(line[1:])

    return likes, hates

def read_data_out(filename):
    file1 = open(filename, 'r')
    return file1.readline().split()[1:]

def read_data_input(filename):
    file1 = open(filename, 'r')
    likes = []
    hates = []
    c = int(file1.readline())
    for _ in range(c):
        line = file1.readline().split()
        likes.append(line[1:])
        line = file1.readline().split()
        hates.append(line[1:])

    return likes, hates

import networkx as nx
from tqdm import tqdm
import numpy as np

def solve_for(task_name):
    likes, hates = read_data(f'input_data/{task_name}.in.txt')
    likes_ingredients = list(likes)
    hates_ingredients = list(hates)
    edges = []
    G = nx.Graph()
    G_original = nx.Graph()
    G.add_nodes_from([i for i in range(len(likes))])
    G_original.add_nodes_from([i for i in range(len(likes))])
    for i1 in range(len(likes)):
        for i2 in range(i1+1, len(likes)):
            all_good = True
            for hate_i in hates[i1]:
                if hate_i in likes[i2]:
                    all_good = False
                    break
            for hate_i in hates[i2]:
                if hate_i in likes[i1]:
                    all_good = False
                    break
            if not all_good:
                G.add_edge(i1, i2)
                G_original.add_edge(i1, i2)
                edges.append([i1,i2])
    degress = np.array([v[1] for v in list(G.degree([i for i in range(len(likes))]))])
    degress_index = np.argsort(degress)
    on_Pizza = read_data_out(f'output_data/{task_name}.out.txt')
    likes, hates = read_data_input(f'input_data/{task_name}.in.txt')
    all_ingredients = []
    for like in likes:
        all_ingredients += like

    for hate in hates:
        all_ingredients += hate

    all_ingredients = list(set(all_ingredients))
    new_on_pizza = np.zeros(len(all_ingredients))
    for ing in on_Pizza:
        new_on_pizza[all_ingredients.index(ing)] = 1
    on_Pizza = new_on_pizza
    new_likes = []
    for like in likes:
        new_like = []
        for ing in like:
            new_like.append(all_ingredients.index(ing))
        new_likes.append(new_like)
    likes = new_likes
    new_hates = []
    for hate in hates:
        new_hate = []
        for ing in hate:
            new_hate.append(all_ingredients.index(ing))
        new_hates.append(new_hate)
    hates = new_hates

    def score_option(ingredients):
        score = 0
        for i in range(len(likes)):
            if np.sum(ingredients[likes[i]]) == len(likes[i]) and np.sum(ingredients[hates[i]]) == 0:
                score += 1
        return score

    def get_current_customers(ingredients):
        customers = []
        not_customers = []
        for i in range(len(likes)):
            if np.sum(ingredients[likes[i]]) == len(likes[i]) and np.sum(ingredients[hates[i]]) == 0:
                customers.append(i)
            else:
                not_customers.append(i)
        return customers, not_customers

    customers, not_customers = get_current_customers(on_Pizza)

    pbar = tqdm(range(500000))
    for i in pbar:
        new_ind = random.choices(customers, k=100)
        new_customers = list(customers)
        for ind in new_ind:
            if ind in new_customers:
                new_customers.remove(ind)
        new_max_ind = nx.algorithms.mis.maximal_independent_set(G_original, new_customers, seed=i)
        pbar.set_postfix(score=len(new_max_ind))
        if len(new_max_ind) > len(customers):
            customers = list(new_max_ind)
            test_ingredients = []
            for i in customers:
                test_ingredients += likes_ingredients[i]
            test_ingredients = list(set(test_ingredients))
            textfile = open(f'output_data/{task_name}.out.txt', "w")
            textfile.write(str(len(test_ingredients)))
            for element in test_ingredients:
                textfile.write(" " + element)
            textfile.close()
            print('New Best:', len(customers))
        if len(new_max_ind) == len(customers):
            customers = list(new_max_ind)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    # solve_for('d_difficult')
    solve_for('e_elaborate')



# See PyCharm help at https://www.jetbrains.com/help/pycharm/
