import random
from networkx_viewer import Viewer


def read_data(filename):
    file1 = open(filename, 'r')
    likes = []
    hates = []
    c = int(file1.readline())
    for _ in range(c):
        line = file1.readline().split()
        likes.append(line[1:])
        line = file1.readline().split()
        hates.append(line[1:])

    return likes, hates

def read_data_out(filename):
    file1 = open(filename, 'r')
    return file1.readline().split()[1:]

def read_data_input(filename):
    file1 = open(filename, 'r')
    likes = []
    hates = []
    c = int(file1.readline())
    for _ in range(c):
        line = file1.readline().split()
        likes.append(line[1:])
        line = file1.readline().split()
        hates.append(line[1:])

    return likes, hates

import networkx as nx
from tqdm import tqdm
import numpy as np
from matplotlib import pylab
import matplotlib.pyplot as plt

def save_graph(graph, file_name):
    # initialze Figure
    plt.figure(num=None, figsize=(20, 20), dpi=80)
    plt.axis('off')
    fig = plt.figure(1)
    pos = nx.spring_layout(graph)
    nx.draw_networkx_nodes(graph, pos)
    nx.draw_networkx_edges(graph, pos)
    nx.draw_networkx_labels(graph, pos)

    cut = 1.00
    xmax = cut * max(xx for xx, yy in pos.values())
    ymax = cut * max(yy for xx, yy in pos.values())
    plt.xlim(0, xmax)
    plt.ylim(0, ymax)

    plt.savefig(file_name, bbox_inches="tight")
    pylab.close()
    del fig
def solve_for(task_name):
    likes, hates = read_data(f'input_data/{task_name}.in.txt')
    likes_ingredients = list(likes)
    edges = []
    G = nx.Graph()
    G_original = nx.Graph()
    G.add_nodes_from([i for i in range(len(likes))])
    G_original.add_nodes_from([i for i in range(len(likes))])
    for i1 in range(len(likes)):
        for i2 in range(i1+1, len(likes)):
            all_good = True
            for hate_i in hates[i1]:
                if hate_i in likes[i2]:
                    all_good = False
                    break
            for hate_i in hates[i2]:
                if hate_i in likes[i1]:
                    all_good = False
                    break
            if not all_good:
                G.add_edge(i1, i2)
                G_original.add_edge(i1, i2)
                edges.append([i1,i2])

    app = Viewer(G, home_node=1, levels=1)
    app.mainloop()
# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    # solve_for('d_difficult')
    solve_for('e_elaborate')



# See PyCharm help at https://www.jetbrains.com/help/pycharm/
