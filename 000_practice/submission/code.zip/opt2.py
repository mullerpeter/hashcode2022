import random


def read_data(filename):
    file1 = open(filename, 'r')
    likes = []
    hates = []
    c = int(file1.readline())
    for _ in range(c):
        line = file1.readline().split()
        likes.append(line[1:])
        line = file1.readline().split()
        hates.append(line[1:])

    return likes, hates

def read_data_out(filename):
    file1 = open(filename, 'r')
    return file1.readline().split()[1:]

def read_data_input(filename):
    file1 = open(filename, 'r')
    likes = []
    hates = []
    c = int(file1.readline())
    for _ in range(c):
        line = file1.readline().split()
        likes.append(line[1:])
        line = file1.readline().split()
        hates.append(line[1:])

    return likes, hates

import networkx as nx
from tqdm import tqdm
import numpy as np

def solve_for(task_name):
    likes, hates = read_data(f'input_data/{task_name}.in.txt')
    likes_ingredients = list(likes)
    hates_ingredients = list(hates)
    edges = []
    G = nx.Graph()
    G_original = nx.Graph()
    G.add_nodes_from([i for i in range(len(likes))])
    G_original.add_nodes_from([i for i in range(len(likes))])
    for i1 in range(len(likes)):
        for i2 in range(i1+1, len(likes)):
            all_good = True
            for hate_i in hates[i1]:
                if hate_i in likes[i2]:
                    all_good = False
                    break
            for hate_i in hates[i2]:
                if hate_i in likes[i1]:
                    all_good = False
                    break
            if not all_good:
                G.add_edge(i1, i2)
                G_original.add_edge(i1, i2)
                edges.append([i1,i2])
    degress = [v[1] for v in list(G.degree([i for i in range(len(likes))]))]
    degress_index = np.argsort(degress)
    on_Pizza = read_data_out(f'output_data/{task_name}.out.txt')
    likes, hates = read_data_input(f'input_data/{task_name}.in.txt')
    all_ingredients = []
    for like in likes:
        all_ingredients += like

    for hate in hates:
        all_ingredients += hate

    all_ingredients = list(set(all_ingredients))
    new_on_pizza = np.zeros(len(all_ingredients))
    for ing in on_Pizza:
        new_on_pizza[all_ingredients.index(ing)] = 1
    on_Pizza = new_on_pizza
    new_likes = []
    for like in likes:
        new_like = []
        for ing in like:
            new_like.append(all_ingredients.index(ing))
        new_likes.append(new_like)
    likes = new_likes
    new_hates = []
    for hate in hates:
        new_hate = []
        for ing in hate:
            new_hate.append(all_ingredients.index(ing))
        new_hates.append(new_hate)
    hates = new_hates

    def score_option(ingredients):
        score = 0
        for i in range(len(likes)):
            if np.sum(ingredients[likes[i]]) == len(likes[i]) and np.sum(ingredients[hates[i]]) == 0:
                score += 1
        return score

    def get_current_customers(ingredients):
        customers = []
        not_customers = []
        for i in range(len(likes)):
            if np.sum(ingredients[likes[i]]) == len(likes[i]) and np.sum(ingredients[hates[i]]) == 0:
                customers.append(i)
            else:
                not_customers.append(i)
        return customers, not_customers

    customers, not_customers = get_current_customers(on_Pizza)

    sorted_list = []
    for c in not_customers:
        neigbours = 0
        neighbour_list = list(G.neighbors(c))
        for n in neighbour_list:
            if n in customers:
                neigbours += 1
        sorted_list.append({
            "customer": c,
            "neigbours": neigbours
        })

    sorted_list = sorted(sorted_list, key=lambda d: d["neigbours"])
    # print(sorted_list)
    def test_random(choice_customer, customers):
        new_customer = list(customers)
        neighbour_list = list(G.neighbors(choice_customer))
        for n in neighbour_list:
            if n in new_customer:
                new_customer.remove(n)
        new_customer.append(choice_customer)
        all_customers = [i for i in range(len(likes))]
        for c in new_customer:
            neighbour_list = list(G.neighbors(c))
            for n in neighbour_list:
                if n in all_customers:
                    all_customers.remove(n)
        if len(all_customers) > len(customers):
            test_ingredients = []
            for i in all_customers:
                test_ingredients += likes_ingredients[i]
            test_ingredients = list(set(test_ingredients))
            textfile = open(f'output_data/{task_name}.out.txt', "w")
            textfile.write(str(len(test_ingredients)))
            for element in test_ingredients:
                textfile.write(" " + element)
            textfile.close()
            return all_customers, True, test_ingredients, 0

        if len(all_customers) == len(customers):
            return all_customers, False, [], 0
            new_likes = []
            for i in all_customers:
                new_likes += likes_ingredients[i]
            new_likes = len(list(set(new_likes)))
            new_hates = []
            for i in all_customers:
                new_hates += hates_ingredients[i]
            new_hates = len(list(set(new_hates)))
            old_likes = []
            for i in customers:
                old_likes += likes_ingredients[i]
            old_likes = len(list(set(old_likes)))
            old_hates = []
            for i in customers:
                old_hates += hates_ingredients[i]
            old_hates = len(list(set(old_hates)))
            if (new_hates + new_likes) < (old_hates + old_likes):
                restrictions = new_hates + new_likes
                test_ingredients = []
                for i in all_customers:
                    test_ingredients += likes_ingredients[i]
                test_ingredients = list(set(test_ingredients))
                return all_customers, True, test_ingredients, restrictions

        return customers, False, [], 0


    test_index = 0
    pbar = tqdm(range(5000))
    for i in pbar:
        test_customer = sorted_list[test_index]["customer"]
        # test_customer = random.choice(not_customers)
        customers, changed, ingred, restrictions = test_random(test_customer, customers)
        test_index += 1
        if changed:
            pbar.set_postfix(score=len(customers), restrictions=restrictions, index=test_index)
            new_on_pizza = np.zeros(len(all_ingredients))
            for ing in ingred:
                new_on_pizza[all_ingredients.index(ing)] = 1
            customers, not_customers = get_current_customers(new_on_pizza)

            sorted_list = []
            for c in not_customers:
                neigbours = 0
                neighbour_list = list(G.neighbors(c))
                for n in neighbour_list:
                    if n in customers:
                        neigbours += 1
                sorted_list.append({
                    "customer": c,
                    "neigbours": neigbours
                })

            sorted_list = sorted(sorted_list, key=lambda d: d["neigbours"])
            if restrictions == 0:
                test_index = 0


# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    # solve_for('d_difficult')
    solve_for('e_elaborate')



# See PyCharm help at https://www.jetbrains.com/help/pycharm/
